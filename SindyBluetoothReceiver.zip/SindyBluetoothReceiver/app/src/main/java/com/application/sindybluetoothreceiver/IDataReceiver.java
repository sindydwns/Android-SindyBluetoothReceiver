package com.application.sindybluetoothreceiver;

/**
 * 데이터를 수신하면 어떻게 처리해야 할까요? 이 IDataReceiver 를 구현(Implement)하여 처리 방법을 서술합니다.
 */
public interface IDataReceiver {
    /**
     * 데이터를 받기 위한 인터페이스
     */
    void SendMessage(String msg);

    /**
     * 데이터 이외의 상태 메시지를 전하기 위한 인터페이스
     */
    void DebugMessage(String msg);
}
