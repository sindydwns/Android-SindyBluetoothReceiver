package com.application.sindybluetoothreceiver;

import android.bluetooth.BluetoothAdapter;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.v7.app.AppCompatActivity;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity implements IDataReceiver {

    // 이 프로젝트는 디바이스 이름을 통해 블루투스 장치를 자동으로 탐색합니다.
    // 그때 사용할 변수입니다.
    private final String deviceName = "ORANGE";

    // BluetoothManager 는 하나의 블루투스 장치로부터 데이터를 지속적으로 수신합니다.
    // 수신한 데이터를 어떻게 처리할지는 IDataReceiver 을 구현(Implement)하여 BluetoothManager 생성자의 매개변수로 전달해야 합니다.
    private BluetoothManager orange;

    // 이 프로젝트에서는 BluetoothManager 로부터 수신한 데이터를 MainActivity 에서 처리하고 있습니다.
    // 앱에 리스트 형태로 데이터를 출력하고자 했기 때문에 ArrayAdapter<String>과 ListView를 선언했고,
    // 다른형태로 출력하려는 경우, 그에 맞는 View 를 선언, 할당해야 합니다.
    private ArrayAdapter<String> listViewAdapter;
    private ListView listView;




    @Override
    // onCreate 메소드는 MainActivity 가 화면에 띄워지기 전에 자동으로 호출됩니다.
    // listView 를 초기화하고 블루투스 권한을 얻고 연결을 시도하고 있습니다.
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        listView = findViewById(R.id.listView);
        listViewAdapter = new ArrayAdapter<String>(getApplicationContext(), R.layout.simple_list_item, new ArrayList<String>());
        listView.setAdapter(listViewAdapter);

        // 블투 권한 얻기 및 연결시도
        if (getBluetoothPermission().isEnabled()) {
            orange = new BluetoothManager("ORANGE", this);
        } else {
            DebugMessage("블투 권한없음");
        }
    }

    // 안드로이드에서는 각각의 앱이 디바이스의 자원을 사용하기 위해 '권한'을 얻어야만 합니다.
    // 이 앱에서도 블루투스 자원을 사용해야 하므로 블루투스 권한을 요청하는 기능을 메소드로 만들었습니다.
    // 이 메소드는 onCreate 에서 호출 됩니다.
    private BluetoothAdapter getBluetoothPermission() {
        BluetoothAdapter bluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
        if (bluetoothAdapter == null) {
            Toast.makeText(getApplicationContext(), "블루투스 지원 안 함", Toast.LENGTH_LONG).show();
        }
        if (!bluetoothAdapter.isEnabled()) {
            Intent enableBtIntent = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
            startActivityForResult(enableBtIntent, 2);
        }
        return bluetoothAdapter;
    }

    @Override
    // IDataReceiver 를 구현(Implement)한 내용 입니다.
    // 아두이노로부터 받은 데이터를 어떻게 처리할지 여기서 서술하시면 됩니다.
    // 지금은 받은 데이터를 listView 에 출력하고 있습니다. 이 내용을 수정하여 원하는 작업을 수행하세요.
    // 파일을 읽고 쓰는 것과 같이 시간이 오래 걸리는 작업은 Thread 사용을 권합니다.
    public void SendMessage(String msg) {
        Bundle data = new Bundle();
        data.putString("message", msg);
        Message message = new Message();
        message.setData(data);
        listViewHandler.sendMessage(message);
    }

    @Override
    // IDataReceiver 를 구현(Implement)한 내용 입니다.
    // 아두이노로부터 받은 데이터가 아닌, 연결 상태나 각종 시스템 이벤트 내용을 받습니다.
    // 지금은 SendMessage 와 동일한 기능을 수행하고 있습니다.
    public void DebugMessage(String msg) {
//        Toast.makeText(getApplicationContext(), msg, Toast.LENGTH_SHORT).show();
        SendMessage(msg);
    }

    // Main Thread 가 아닌 기타 Thread 에서 View 에 직접 접근할 경우 에러가 발생합니다.
    // BluetoothManager 는 Main Thread 가 아닌 기타 Thread 에서 데이터를 수신하고 있기 때문에 View 에 접근할 수 없습니다.
    // 이를 해결하기 위하여 Handler 를 이용하여 간접적인 방법으로 View 에 값을 출력하려고 합니다.
    private Handler listViewHandler = new Handler() {
        public void handleMessage(Message msg) {
            super.handleMessage(msg);
            listViewAdapter.insert(msg.getData().getString("message"), 0);
        }
    };

    @Override
    // MainActivity 가 종료될 때, 연결된 블루투스도 해제합니다.
    protected void onDestroy() {
        super.onDestroy();
        orange.disconnectDevice();
    }
}
