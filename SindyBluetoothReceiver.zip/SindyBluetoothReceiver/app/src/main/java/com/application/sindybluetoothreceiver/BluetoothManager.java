package com.application.sindybluetoothreceiver;

import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;

import java.io.IOException;
import java.io.InputStream;
import java.util.Set;
import java.util.UUID;

/**
 * HC-06 블루투스 모듈로부터 지속적으로 데이터를 받는 매니저.
 * @author sindydwns@naver.com
 */
public class BluetoothManager {

    private BluetoothDevice bluetoothDevice;
    private IDataReceiver debugManager;
    private final UUID MY_UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");
    private BluetoothSocket socket;
    private String deviceName;

    // 연결 쓰레드와 데이터 수신 쓰레드
    private ConnectThread connector;
    private ReceiveThread receiver;

    // variables for state machine
    private boolean stateDeviceFind = false;
    private boolean stateConnected = false;
    private boolean stateReceiving = false;

    public BluetoothManager(String deviceNameFind, IDataReceiver rsv) {

        this.deviceName = deviceNameFind;
        this.debugManager = rsv;

        Set<BluetoothDevice> pairedDevices = BluetoothAdapter.getDefaultAdapter().getBondedDevices();
        if (pairedDevices.size() == 0) return;
        for (BluetoothDevice device : pairedDevices) {
            String deviceName = device.getName();
            if (deviceName.equals(deviceNameFind)) {
                this.stateDeviceFind = true;
                this.bluetoothDevice = device;
            }
        }

        if (this.stateDeviceFind) {
            debugManager.DebugMessage("디바이스를 찾음. 연결 시도 중...");
            connectDevice();
        } else {
            debugManager.DebugMessage("디바이스를 찾지 못함");
        }
    }

    public BluetoothDevice getDevice() {
        return this.bluetoothDevice;
    }

    public boolean IsConnected() {
        return stateConnected;
    }

    public void RetryConnect() {
        this.disconnectDevice();

        // 디바이스 서치
        Set<BluetoothDevice> pairedDevices = BluetoothAdapter.getDefaultAdapter().getBondedDevices();
        if (pairedDevices.size() == 0) return;
        for (BluetoothDevice device : pairedDevices) {
            String deviceName = device.getName();
            if (deviceName.equals(this.deviceName)) {
                this.stateDeviceFind = true;
                this.bluetoothDevice = device;
            }
        }

        // 디바이스 서치 성공시 연결 수행
        if (this.stateDeviceFind) {
            this.connectDevice();
        }
    }

    public void disconnectDevice() {
        if (receiver != null) {
            receiver.killThread();
        }
        if (connector != null) {
            connector.killConnect();
        }
    }

    private void connectDevice() {
        if (this.stateDeviceFind) {
            disconnectDevice();
            this.connector = new ConnectThread();
            this.connector.start();
        }
    }

    private void receiveDevice() {
        if (this.stateConnected) {
            this.receiver = new ReceiveThread();
            this.receiver.start();
        }
    }

    private class ConnectThread extends Thread {

        @Override
        public void run() {
            super.run();
            socket = getSocket(bluetoothDevice);

            try {
                debugManager.DebugMessage("블투 연결 시도 [" + deviceName + "]");
                socket.connect();
            } catch (IOException connectException) {
                try {
                    socket.close();
                } catch (IOException closeException) {
                }
                debugManager.DebugMessage("블투 연결에 실패");
                stateConnected = false;
                return;
            }

            stateConnected = true;
            debugManager.DebugMessage("블투 연결에 성공");

            receiveDevice();
        }

        public void killConnect() {
            try {
                debugManager.DebugMessage("killConnect");
                socket.close();
            } catch (IOException e) {
            }

            stateConnected = false;
        }

        private BluetoothSocket getSocket(BluetoothDevice device) {
            try {
                return device.createRfcommSocketToServiceRecord(MY_UUID);
            } catch (IOException e) {
            }
            return null;
        }

    }

    private class ReceiveThread extends Thread {

        private boolean running = true;
        private int pivot = 0;
        public InputStream input;

        @Override
        public void run() {
            super.run();
            debugManager.DebugMessage("데이터 수신 준비 완료. 지속적으로 읽는 중...");
            stateReceiving = true;
            running = true;

            InputStream input = getInputStream(socket);
            if (input == null) return;

            final byte[] buffer = new byte[1024];

            while (running) {
                try {
                    String message = GetData(input, buffer);
                    if (message == null) {
                        continue;
                    }

                    receivedData(message);

                } catch (IOException e) {
                    debugManager.DebugMessage("[err] 데이터 수신 실패. " + e);
                }
            }

            stateReceiving = false;
        }

        public void killThread() {
            this.running = false;
        }

        private void receivedData(String data) {
            debugManager.SendMessage(data);
        }

        private String GetData(InputStream input, byte[] buffer) throws IOException {
            int size = input.available();
            if (size == 0) {
                return null;
            }
            byte[] bytes = new byte[size];
            byte[] result = null;
            input.read(bytes);
            for (int i = 0; i < size; i++) {
                if (bytes[i] == '\n') {
                    if (pivot == 0) continue;
                    byte[] temp = new byte[pivot - 1];
                    System.arraycopy(buffer, 0, temp, 0, pivot - 1);
                    result = temp;
                    pivot = 0;
                } else {
                    buffer[pivot] = bytes[i];
                    pivot++;
                }
            }
            if (result == null) {
                return null;
            } else {
                return new String(result, "UTF-8");
            }
        }

        private InputStream getInputStream(BluetoothSocket socket) {
            InputStream input = null;
            try {
                input = socket.getInputStream();
            } catch (IOException e) {
                debugManager.DebugMessage("데이터 스트림 연결 실패");
            }
            return input;
        }
    }
}
